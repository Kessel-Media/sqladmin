::: sqladmin.application.Admin
    handler: python
    selection:
      members:
        - __init__

::: sqladmin.application.BaseAdmin
    handler: python
    selection:
      members:
        - model_admins
        - register_model
